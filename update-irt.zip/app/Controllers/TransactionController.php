<?php
namespace App\Controllers;

use App\Models\Transaction;

class TransactionController {
    private Transaction $transactionModel;

    public function __construct() {
        $this->transactionModel = new Transaction();
    }

    /**
     * List all transactions with filter queries
     */
    public function index(): void {
        // Get current salary-based budget period as default dates
        $period = getBudgetPeriod();
        
        // Collect filters from GET request parameters
        $filters = [
            'type' => $_GET['type'] ?? '',
            'category_id' => $_GET['category_id'] ?? '',
            'start_date' => isset($_GET['start_date']) ? $_GET['start_date'] : $period['start_date'],
            'end_date' => isset($_GET['end_date']) ? $_GET['end_date'] : $period['end_date']
        ];

        // Fetch filtered list
        $transactions = $this->transactionModel->getAll($filters);
        
        // Fetch categories for input forms and filters
        $categories = $this->transactionModel->getCategories();
        $incomeCategories = $this->transactionModel->getCategories('income');
        $expenseCategories = $this->transactionModel->getCategories('expense');

        // Fetch dynamic summary for current filters
        $summary = $this->transactionModel->getSummary($filters);

        $title = "Kelola Transaksi - IRT";

        // Load the view inside templates
        require dirname(__DIR__, 2) . '/views/templates/header.php';
        require dirname(__DIR__, 2) . '/views/transactions/index.php';
        require dirname(__DIR__, 2) . '/views/templates/footer.php';
    }

    /**
     * Save a new transaction record
     */
    public function store(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $amount = $_POST['amount'] ?? 0;
            $type = $_POST['type'] ?? '';
            $categoryId = $_POST['category_id'] ?? '';
            $date = $_POST['date'] ?? '';
            $description = $_POST['description'] ?? '';

            // Simple validation
            if (empty($amount) || empty($type) || empty($date)) {
                setFlash('error', 'Harap isi jumlah uang, jenis transaksi, dan tanggal!');
                header('Location: ' . baseUrl('transactions'));
                exit;
            }

            $success = $this->transactionModel->create([
                'category_id' => $categoryId,
                'amount' => $amount,
                'type' => $type,
                'date' => $date,
                'description' => $description
            ]);

            if ($success) {
                setFlash('success', 'Transaksi keuangan berhasil dicatat!');
            } else {
                setFlash('error', 'Gagal mencatat transaksi. Silakan coba kembali.');
            }
        }

        header('Location: ' . baseUrl('transactions'));
        exit;
    }

    /**
     * Edit / update an existing transaction record
     */
    public function update(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'] ?? 0;
            $amount = $_POST['amount'] ?? 0;
            $type = $_POST['type'] ?? 'expense';
            $category_id = $_POST['category_id'] ?? null;
            $date = $_POST['date'] ?? date('Y-m-d');
            $description = trim($_POST['description'] ?? '');

            if (empty($id)) {
                setFlash('error', 'ID transaksi tidak valid!');
                header('Location: ' . baseUrl('transactions'));
                exit;
            }

            if (empty($amount) || $amount <= 0) {
                setFlash('error', 'Jumlah uang harus lebih besar dari 0!');
                header('Location: ' . baseUrl('transactions'));
                exit;
            }

            $success = $this->transactionModel->update((int)$id, [
                'category_id' => $category_id,
                'amount' => (float)$amount,
                'type' => $type,
                'date' => $date,
                'description' => $description
            ]);

            if ($success) {
                setFlash('success', 'Transaksi keuangan berhasil diperbarui!');
            } else {
                setFlash('error', 'Gagal memperbarui transaksi. Silakan coba kembali.');
            }
        }

        header('Location: ' . baseUrl('transactions'));
        exit;
    }

    /**
     * Delete an existing transaction record
     */
    public function destroy(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'] ?? 0;
            
            if (empty($id)) {
                setFlash('error', 'ID transaksi tidak valid!');
                header('Location: ' . baseUrl('transactions'));
                exit;
            }

            $success = $this->transactionModel->delete((int)$id);

            if ($success) {
                setFlash('success', 'Catatan transaksi telah berhasil dihapus!');
            } else {
                setFlash('error', 'Gagal menghapus catatan transaksi.');
            }
        }

        header('Location: ' . baseUrl('transactions'));
        exit;
    }
}
