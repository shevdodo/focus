<?php
namespace App\Controllers;

use App\Models\Transaction;

class ReportController {
    private Transaction $transactionModel;

    public function __construct() {
        $this->transactionModel = new Transaction();
    }

    /**
     * Render the expense allocation report page with month picker and 28th payday budget period
     */
    public function index(): void {
        // Selected month parameter (YYYY-MM), defaults to current salary period
        $selectedMonth = $_GET['month'] ?? '';
        
        // Calculate budget period (starts on 28th of previous month, ends on 27th of target month)
        $period = getBudgetPeriodByMonth($selectedMonth);
        $currentMonthStart = $period['start_date'];
        $currentMonthEnd = $period['end_date'];
        $selectedMonthValue = $period['year_month'] ?? date('Y-m');

        // Fetch list of available budget months for select picker (only periods with database records)
        $availableMonths = getAvailableBudgetMonths($selectedMonthValue);

        // Calculate previous and next month values for navigation buttons
        $endDateTimeObj = new \DateTime($currentMonthEnd);
        $prevMonthValue = (clone $endDateTimeObj)->modify('-1 month')->format('Y-m');
        $nextMonthValue = (clone $endDateTimeObj)->modify('+1 month')->format('Y-m');

        // Fetch ALL expense category allocations for this period
        $categoryAllocations = $this->transactionModel->getAllExpenseCategoryAllocation([
            'start_date' => $currentMonthStart,
            'end_date' => $currentMonthEnd
        ]);

        // Fetch overall period financial summary
        $periodSummary = $this->transactionModel->getSummary([
            'start_date' => $currentMonthStart,
            'end_date' => $currentMonthEnd
        ]);

        // Fetch detailed expense transactions for category breakdown details
        $periodExpenses = $this->transactionModel->getAll([
            'start_date' => $currentMonthStart,
            'end_date' => $currentMonthEnd,
            'type' => 'expense'
        ]);

        // Calculate metrics
        $totalExpense = (float)$periodSummary['total_expense'];
        $totalIncome = (float)$periodSummary['total_income'];
        $periodBalance = (float)$periodSummary['balance'];

        $activeCategoriesCount = 0;
        foreach ($categoryAllocations as $cat) {
            if ((float)$cat['total_amount'] > 0) {
                $activeCategoriesCount++;
            }
        }
        $totalCategoriesCount = count($categoryAllocations);

        // View meta variables
        $title = "Laporan Rekap Alokasi Pengeluaran - IRT";
        $periodLabel = $period['label'];
        $periodStartFormatted = formatIndonesianDate($currentMonthStart);
        $periodEndFormatted = formatIndonesianDate($currentMonthEnd);

        // Load templates
        require dirname(__DIR__, 2) . '/views/templates/header.php';
        require dirname(__DIR__, 2) . '/views/reports/index.php';
        require dirname(__DIR__, 2) . '/views/templates/footer.php';
    }
}
