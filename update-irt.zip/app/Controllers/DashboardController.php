<?php
namespace App\Controllers;

use App\Models\Transaction;

class DashboardController {
    public function index(): void {
        $transactionModel = new Transaction();

        // Get overall lifetime summary
        $summary = $transactionModel->getSummary();

        // Get salary-based budget period (starts on 28th of previous month)
        $period = getBudgetPeriod();
        $currentMonthStart = $period['start_date'];
        $currentMonthEnd = $period['end_date'];
        
        $monthlySummary = $transactionModel->getSummary([
            'start_date' => $currentMonthStart,
            'end_date' => $currentMonthEnd
        ]);

        // Get category summaries for charts/visual bars filtered by current period
        $categoryExpenses = $transactionModel->getCategorySummary('expense', [
            'start_date' => $currentMonthStart,
            'end_date' => $currentMonthEnd
        ]);
        $categoryIncomes = $transactionModel->getCategorySummary('income', [
            'start_date' => $currentMonthStart,
            'end_date' => $currentMonthEnd
        ]);

        // Get recent 5 transactions
        $allTransactions = $transactionModel->getAll();
        $recentTransactions = array_slice($allTransactions, 0, 5);

        // Define view details and localized period labels
        $title = "Dashboard Keuangan - IRT";
        $periodLabel = $period['label'];
        $periodStartFormatted = formatIndonesianDate($currentMonthStart);
        $periodEndFormatted = formatIndonesianDate($currentMonthEnd);
        
        // Render views with header and footer templates
        require dirname(__DIR__, 2) . '/views/templates/header.php';
        require dirname(__DIR__, 2) . '/views/dashboard.php';
        require dirname(__DIR__, 2) . '/views/templates/footer.php';
    }
}
