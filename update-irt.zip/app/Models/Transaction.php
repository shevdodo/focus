<?php
namespace App\Models;

use App\Config\Database;
use PDO;

class Transaction {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    /**
     * Get all transactions with category details
     */
    public function getAll(array $filters = []): array {
        $sql = "
            SELECT t.*, c.name as category_name, c.color as category_color, c.icon as category_icon 
            FROM transactions t
            LEFT JOIN categories c ON t.category_id = c.id
        ";
        
        $conditions = [];
        $params = [];

        if (!empty($filters['type'])) {
            $conditions[] = "t.type = :type";
            $params[':type'] = $filters['type'];
        }

        if (!empty($filters['category_id'])) {
            $conditions[] = "t.category_id = :category_id";
            $params[':category_id'] = $filters['category_id'];
        }

        if (!empty($filters['start_date'])) {
            $conditions[] = "t.date >= :start_date";
            $params[':start_date'] = $filters['start_date'];
        }

        if (!empty($filters['end_date'])) {
            $conditions[] = "t.date <= :end_date";
            $params[':end_date'] = $filters['end_date'];
        }

        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }

        $sql .= " ORDER BY t.date DESC, t.id DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Get consolidated summary totals (Income, Expense, Balance)
     */
    public function getSummary(array $filters = []): array {
        $sql = "
            SELECT 
                SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) as total_income,
                SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expense
            FROM transactions
        ";

        $conditions = [];
        $params = [];

        if (!empty($filters['start_date'])) {
            $conditions[] = "date >= :start_date";
            $params[':start_date'] = $filters['start_date'];
        }

        if (!empty($filters['end_date'])) {
            $conditions[] = "date <= :end_date";
            $params[':end_date'] = $filters['end_date'];
        }

        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();

        $income = (float)($result['total_income'] ?? 0);
        $expense = (float)($result['total_expense'] ?? 0);
        $balance = $income - $expense;

        return [
            'total_income' => $income,
            'total_expense' => $expense,
            'balance' => $balance
        ];
    }

    /**
     * Get transactions aggregated by category for analytics
     */
    public function getCategorySummary(string $type = 'expense', array $filters = []): array {
        $sql = "
            SELECT c.name as category_name, c.color as category_color, c.icon as category_icon, SUM(t.amount) as total_amount
            FROM transactions t
            INNER JOIN categories c ON t.category_id = c.id
            WHERE t.type = :type
        ";
        
        $params = [':type' => $type];

        if (!empty($filters['start_date'])) {
            $sql .= " AND t.date >= :start_date";
            $params[':start_date'] = $filters['start_date'];
        }

        if (!empty($filters['end_date'])) {
            $sql .= " AND t.date <= :end_date";
            $params[':end_date'] = $filters['end_date'];
        }

        $sql .= "
            GROUP BY t.category_id, c.name, c.color, c.icon
            ORDER BY total_amount DESC
        ";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Get ALL expense categories with total spending, transaction count, and metadata for reports
     */
    public function getAllExpenseCategoryAllocation(array $filters = []): array {
        $sql = "
            SELECT 
                c.id as category_id,
                c.name as category_name,
                c.color as category_color,
                c.icon as category_icon,
                COALESCE(SUM(t.amount), 0) as total_amount,
                COUNT(t.id) as transaction_count
            FROM categories c
            LEFT JOIN transactions t ON t.category_id = c.id 
                AND t.type = 'expense'
        ";
        
        $conditions = [];
        $params = [];

        if (!empty($filters['start_date'])) {
            $conditions[] = "t.date >= :start_date";
            $params[':start_date'] = $filters['start_date'];
        }

        if (!empty($filters['end_date'])) {
            $conditions[] = "t.date <= :end_date";
            $params[':end_date'] = $filters['end_date'];
        }

        if (!empty($conditions)) {
            $sql .= " AND " . implode(" AND ", $conditions);
        }

        $sql .= "
            WHERE c.type = 'expense'
            GROUP BY c.id, c.name, c.color, c.icon
            ORDER BY total_amount DESC, c.name ASC
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Save a new transaction
     */
    public function create(array $data): bool {
        $sql = "
            INSERT INTO transactions (category_id, amount, type, date, description) 
            VALUES (:category_id, :amount, :type, :date, :description)
        ";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':category_id' => $data['category_id'] ? (int)$data['category_id'] : null,
            ':amount' => (float)$data['amount'],
            ':type' => $data['type'],
            ':date' => $data['date'],
            ':description' => htmlspecialchars($data['description'] ?? '', ENT_QUOTES, 'UTF-8')
        ]);
    }

    /**
     * Update an existing transaction record by ID
     */
    public function update(int $id, array $data): bool {
        $sql = "
            UPDATE transactions 
            SET category_id = :category_id, 
                amount = :amount, 
                type = :type, 
                date = :date, 
                description = :description
            WHERE id = :id
        ";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id,
            ':category_id' => $data['category_id'] ? (int)$data['category_id'] : null,
            ':amount' => (float)$data['amount'],
            ':type' => $data['type'],
            ':date' => $data['date'],
            ':description' => htmlspecialchars($data['description'] ?? '', ENT_QUOTES, 'UTF-8')
        ]);
    }

    /**
     * Remove a transaction by ID
     */
    public function delete(int $id): bool {
        $sql = "DELETE FROM transactions WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }

    /**
     * Fetch financial categories
     */
    public function getCategories(string $type = null): array {
        $sql = "SELECT * FROM categories";
        $params = [];
        
        if ($type !== null) {
            $sql .= " WHERE type = :type";
            $params[':type'] = $type;
        }
        
        $sql .= " ORDER BY name ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
