<?php
namespace App\Config;

use PDO;
use PDOException;

class Database {
    private static ?PDO $instance = null;

    public static function getConnection(): PDO {
        if (self::$instance === null) {
            try {
                $dbPath = dirname(__DIR__, 2) . '/database/keuangan.db';
                $dbDir = dirname($dbPath);
                
                // Create database directory if it doesn't exist
                if (!is_dir($dbDir)) {
                    mkdir($dbDir, 0755, true);
                }

                $isNew = !file_exists($dbPath);

                self::$instance = new PDO("sqlite:" . $dbPath);
                self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$instance->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                
                // Enable foreign keys
                self::$instance->exec('PRAGMA foreign_keys = ON;');

                if ($isNew) {
                    self::initializeDatabase(self::$instance);
                }
            } catch (PDOException $e) {
                die("Koneksi database gagal: " . $e->getMessage());
            }
        }
        return self::$instance;
    }

    private static function initializeDatabase(PDO $db): void {
        // Create users table
        $db->exec("
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                name TEXT,
                role TEXT NOT NULL DEFAULT 'user'
            );
        ");

        // Seed default administrative user
        $username = 'admin';
        $password = password_hash('admin', PASSWORD_DEFAULT);
        $name = 'Keluarga Sejahtera';
        $role = 'admin';
        
        $stmtUser = $db->prepare("INSERT OR IGNORE INTO users (username, password, name, role) VALUES (?, ?, ?, ?)");
        $stmtUser->execute([$username, $password, $name, $role]);

        // Create categories table
        $db->exec("
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
                color TEXT DEFAULT '#4f46e5',
                icon TEXT
            );
        ");

        // Create transactions table
        $db->exec("
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_id INTEGER,
                amount REAL NOT NULL,
                type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
                date TEXT NOT NULL,
                description TEXT,
                FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
            );
        ");

        // Seed default categories
        $categories = [
            ['Gaji', 'income', '#10b981', 'cash-outline'],
            ['Investasi', 'income', '#3b82f6', 'trending-up-outline'],
            ['Bonus', 'income', '#f59e0b', 'gift-outline'],
            ['Pengembalian', 'income', '#14b8a6', 'refresh-outline'],
            ['Makanan & Minuman', 'expense', '#ef4444', 'fast-food-outline'],
            ['Transportasi', 'expense', '#3b82f6', 'car-outline'],
            ['Belanja Bulanan', 'expense', '#ec4899', 'cart-outline'],
            ['Listrik, Air & Internet', 'expense', '#f59e0b', 'flash-outline'],
            ['Kesehatan', 'expense', '#10b981', 'medical-outline'],
            ['Pendidikan', 'expense', '#8b5cf6', 'book-outline'],
            ['Hiburan & Rekreasi', 'expense', '#a855f7', 'film-outline'],
            ['Angsuran', 'expense', '#f43f5e', 'card-outline'],
            ['Admin bank', 'expense', '#64748b', 'receipt-outline'],
            ['Biaya transfer', 'expense', '#06b6d4', 'swap-horizontal-outline'],
            ['Jajan', 'expense', '#f97316', 'ice-cream-outline'],
            ['Dll', 'expense', '#6b7280', 'ellipsis-horizontal-outline']
        ];

        $stmt = $db->prepare("INSERT INTO categories (name, type, color, icon) VALUES (?, ?, ?, ?)");
        foreach ($categories as $cat) {
            $stmt->execute($cat);
        }

        // Seed realistic sample transactions for the current month and last month
        $currentMonth = date('Y-m');
        $prevMonth = date('Y-m', strtotime('-1 month'));

        $transactions = [
            // Current Month
            [1, 5500000, 'income', "$currentMonth-01", 'Gaji Bulanan Utama'],
            [2, 450000, 'income', "$currentMonth-10", 'Dividen Reksadana'],
            [4, 180000, 'expense', "$currentMonth-02", 'Belanja Bahan Makanan Mingguan'],
            [5, 150000, 'expense', "$currentMonth-03", 'Isi Bensin Motor & Mobil'],
            [7, 650000, 'expense', "$currentMonth-05", 'Tagihan Listrik & WiFi IndiHome'],
            [6, 350000, 'expense', "$currentMonth-08", 'Makan Malam Akhir Pekan'],
            [8, 95000, 'expense', "$currentMonth-12", 'Beli Vitamin dan Obat Apotek'],
            [10, 200000, 'expense', "$currentMonth-15", 'Tiket Bioskop & Snack'],
            
            // Last Month
            [1, 5500000, 'income', "$prevMonth-01", 'Gaji Bulanan Utama'],
            [3, 750000, 'income', "$prevMonth-15", 'Bonus Pencapaian Kerja'],
            [4, 250000, 'expense', "$prevMonth-03", 'Makan Malam Keluarga'],
            [7, 620000, 'expense', "$prevMonth-05", 'Tagihan Listrik & WiFi'],
            [9, 1200000, 'expense', "$prevMonth-10", 'Pembelian Buku & Kursus Anak'],
            [5, 150000, 'expense', "$prevMonth-12", 'Isi Bensin Mobil']
        ];

        $stmtTrans = $db->prepare("INSERT INTO transactions (category_id, amount, type, date, description) VALUES (?, ?, ?, ?, ?)");
        foreach ($transactions as $trans) {
            $stmtTrans->execute($trans);
        }
    }
}
