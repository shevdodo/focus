<?php
/**
 * Transactions View
 * Split-layout with filtered transaction list and a quick creation form
 */

if (!function_exists('formatRupiah')) {
    function formatRupiah(float $amount): string {
        return 'Rp ' . number_format($amount, 0, ',', '.');
    }
}
?>

<div class="row-layout">
    <!-- Left Column: Filter and Transaction Table -->
    <div class="col-8">
        
        <!-- Filters Card -->
        <div class="card-widget mb-4">
            <div class="card-widget-header">
                <h3>Filter Catatan</h3>
            </div>
            
            <form method="GET" action="<?= baseUrl('transactions') ?>" class="filter-form">
                <div class="filter-grid">
                    <!-- Type Filter -->
                    <div class="form-group">
                        <label for="filter-type">Jenis</label>
                        <select name="type" id="filter-type" class="form-control">
                            <option value="">Semua</option>
                            <option value="income" <?= ($filters['type'] ?? '') === 'income' ? 'selected' : '' ?>>Pemasukan</option>
                            <option value="expense" <?= ($filters['type'] ?? '') === 'expense' ? 'selected' : '' ?>>Pengeluaran</option>
                        </select>
                    </div>

                    <!-- Category Filter -->
                    <div class="form-group">
                        <label for="filter-category">Kategori</label>
                        <select name="category_id" id="filter-category" class="form-control">
                            <option value="">Semua Kategori</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>" <?= ($filters['category_id'] ?? '') == $cat['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['name']) ?> (<?= $cat['type'] === 'income' ? 'Masuk' : 'Keluar' ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Start Date -->
                    <div class="form-group">
                        <label for="filter-start-date">Dari Tanggal</label>
                        <input type="date" name="start_date" id="filter-start-date" class="form-control" value="<?= $filters['start_date'] ?? '' ?>">
                    </div>

                    <!-- End Date -->
                    <div class="form-group">
                        <label for="filter-end-date">Hingga Tanggal</label>
                        <input type="date" name="end_date" id="filter-end-date" class="form-control" value="<?= $filters['end_date'] ?? '' ?>">
                    </div>
                </div>

                <div class="filter-actions mt-3">
                    <button type="submit" class="btn btn-primary px-4">
                        <ion-icon name="funnel-outline" class="mr-1"></ion-icon>
                        Terapkan Filter
                    </button>
                    <?php if (!empty($filters['type']) || !empty($filters['category_id']) || !empty($filters['start_date']) || !empty($filters['end_date'])): ?>
                        <a href="<?= baseUrl('transactions') ?>" class="btn btn-secondary px-3">
                            Reset
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Filtered Mini Statistics -->
        <div class="monthly-breakdown-card mb-4" style="background: rgba(255, 255, 255, 0.6); padding: 1.25rem;">
            <div class="monthly-grid" style="grid-template-columns: repeat(3, 1fr);">
                <div class="monthly-stat-item">
                    <span class="monthly-label text-xs">Pemasukan Terfilter</span>
                    <h5 class="text-emerald font-weight-bold" style="font-size: 1.15rem; margin-top: 0.25rem;">
                        <?= formatRupiah($summary['total_income']) ?>
                    </h5>
                </div>
                <div class="monthly-separator"></div>
                <div class="monthly-stat-item">
                    <span class="monthly-label text-xs">Pengeluaran Terfilter</span>
                    <h5 class="text-danger font-weight-bold" style="font-size: 1.15rem; margin-top: 0.25rem;">
                        <?= formatRupiah($summary['total_expense']) ?>
                    </h5>
                </div>
                <div class="monthly-separator"></div>
                <div class="monthly-stat-item">
                    <span class="monthly-label text-xs">Selisih Terfilter</span>
                    <h5 class="<?= $summary['balance'] >= 0 ? 'text-emerald' : 'text-danger' ?> font-weight-bold" style="font-size: 1.15rem; margin-top: 0.25rem;">
                        <?= formatRupiah($summary['balance']) ?>
                    </h5>
                </div>
            </div>
        </div>

        <!-- Transactions List (Modern Card List) -->
        <div class="card-widget">
            <div class="card-widget-header">
                <div>
                    <h3>Riwayat Transaksi</h3>
                    <p class="text-muted text-xs">Daftar seluruh transaksi yang berhasil dicatat dalam sistem.</p>
                </div>
                <span class="badge-category" style="background-color: #e0e7ff; color: #4f46e5;">
                    <ion-icon name="receipt-outline"></ion-icon>
                    <span><?= count($transactions) ?> Catatan</span>
                </span>
            </div>
            
            <div class="tx-cards-container">
                <?php if (empty($transactions)): ?>
                    <div class="text-center py-5 text-muted">
                        <ion-icon name="document-text-outline" style="font-size: 2.5rem; color: var(--text-muted); opacity: 0.6;"></ion-icon>
                        <p class="mt-2">Tidak ditemukan catatan transaksi yang sesuai dengan filter.</p>
                    </div>
                <?php else: ?>
                    <div class="tx-cards-list">
                        <?php foreach ($transactions as $tx): ?>
                            <div class="tx-card-item">
                                <!-- Top Row: Icon + Description Title and Amount -->
                                <div class="tx-card-header-row">
                                    <div class="tx-card-title-group">
                                        <div class="tx-icon-avatar" style="background-color: <?= $tx['category_color'] ?? ($tx['type'] === 'income' ? '#10b981' : '#ef4444') ?>18; color: <?= $tx['category_color'] ?? ($tx['type'] === 'income' ? '#10b981' : '#ef4444') ?>;">
                                            <ion-icon name="<?= $tx['category_icon'] ?? ($tx['type'] === 'income' ? 'arrow-down-circle-outline' : 'arrow-up-circle-outline') ?>"></ion-icon>
                                        </div>
                                        <strong class="tx-description-text"><?= htmlspecialchars($tx['description'] ?: 'Transaksi Tanpa Keterangan') ?></strong>
                                    </div>

                                    <span class="tx-amount-value <?= $tx['type'] === 'income' ? 'text-emerald' : 'text-danger' ?>">
                                        <?= $tx['type'] === 'income' ? '+' : '-' ?> <?= formatRupiah($tx['amount']) ?>
                                    </span>
                                </div>

                                <!-- Bottom Row: Date & Category Pill (left), Action buttons (right) -->
                                <div class="tx-card-footer-row">
                                    <div class="tx-sub-meta">
                                        <span class="tx-date-badge">
                                            <ion-icon name="calendar-outline"></ion-icon>
                                            <?= date('d M Y', strtotime($tx['date'])) ?>
                                        </span>
                                        <span class="badge-category-pill" style="background-color: <?= $tx['category_color'] ?? '#6366f1' ?>15; color: <?= $tx['category_color'] ?? '#6366f1' ?>;">
                                            <ion-icon name="<?= $tx['category_icon'] ?? 'bookmark-outline' ?>"></ion-icon>
                                            <span><?= htmlspecialchars($tx['category_name'] ?? 'Lainnya') ?></span>
                                        </span>
                                    </div>

                                    <div class="tx-card-actions">
                                        <button class="btn-action-delete" style="color: var(--color-primary); background: none;" 
                                                onclick="openEditTransactionModal(<?= htmlspecialchars(json_encode([
                                                    'id' => $tx['id'],
                                                    'amount' => $tx['amount'],
                                                    'type' => $tx['type'],
                                                    'category_id' => $tx['category_id'],
                                                    'date' => $tx['date'],
                                                    'description' => $tx['description']
                                                ])) ?>)" 
                                                title="Ubah Catatan">
                                            <ion-icon name="create-outline" style="font-size: 1.25rem;"></ion-icon>
                                        </button>

                                        <form method="POST" action="<?= baseUrl('transactions/delete') ?>" onsubmit="return confirm('Apakah Anda yakin ingin menghapus catatan transaksi ini?');" style="margin: 0; padding: 0;">
                                            <input type="hidden" name="id" value="<?= $tx['id'] ?>">
                                            <button type="submit" class="btn-action-delete" title="Hapus Catatan">
                                                <ion-icon name="trash-outline"></ion-icon>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Right Column: Quick Add Form -->
    <div class="col-4">
        <div class="card-widget sticky-sidebar">
            <div class="card-widget-header">
                <h3>Catat Transaksi</h3>
            </div>
            
            <form method="POST" action="<?= baseUrl('transactions/create') ?>" class="quick-add-form">
                <!-- Amount Field -->
                <div class="form-group mb-3">
                    <label for="amount">Jumlah Uang (Rupiah) <span class="text-danger">*</span></label>
                    <div class="input-currency-wrapper">
                        <span class="currency-prefix">Rp</span>
                        <input type="number" name="amount" id="amount" class="form-control" placeholder="0" min="1" step="any" required>
                    </div>
                </div>

                <!-- Transaction Type Toggle -->
                <div class="form-group mb-3">
                    <label>Jenis Transaksi <span class="text-danger">*</span></label>
                    <div class="type-selector-group">
                        <label class="type-selector-label type-expense active" id="type-label-expense">
                            <input type="radio" name="type" value="expense" checked required>
                            <ion-icon name="arrow-up-circle-outline"></ion-icon>
                            <span>Pengeluaran</span>
                        </label>
                        <label class="type-selector-label type-income" id="type-label-income">
                            <input type="radio" name="type" value="income" required>
                            <ion-icon name="arrow-down-circle-outline"></ion-icon>
                            <span>Pemasukan</span>
                        </label>
                    </div>
                </div>

                <!-- Category Field -->
                <div class="form-group mb-3">
                    <label for="category_id">Kategori Transaksi</label>
                    <select name="category_id" id="category_id" class="form-control">
                        <option value="">-- Pilih Kategori --</option>
                        
                        <!-- Expense categories -->
                        <?php foreach ($expenseCategories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" data-type="expense" class="cat-option">
                                <?= htmlspecialchars($cat['name']) ?>
                            </option>
                        <?php endforeach; ?>
                        
                        <!-- Income categories -->
                        <?php foreach ($incomeCategories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" data-type="income" class="cat-option" style="display: none;">
                                <?= htmlspecialchars($cat['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Date Field -->
                <div class="form-group mb-3">
                    <label for="date">Tanggal Transaksi <span class="text-danger">*</span></label>
                    <input type="date" name="date" id="date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>

                <!-- Description Field -->
                <div class="form-group mb-4">
                    <label for="description">Keterangan / Deskripsi</label>
                    <textarea name="description" id="description" class="form-control" rows="3" placeholder="Contoh: Belanja beras, bayar wifi, dll."></textarea>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary w-100 py-3 rounded-pill shadow-sm">
                    <span class="d-flex align-items-center justify-content-center">
                        <ion-icon name="save-outline" class="mr-2" style="font-size: 1.2rem;"></ion-icon>
                        Simpan Catatan
                    </span>
                </button>
            </form>
        </div>
    </div>
</div>

<!-- ==========================================================================
   MODAL DIALOG - UBAH TRANSAKSI (EDIT TRANSACTION)
   ========================================================================== -->
<div id="editTransactionModal" class="modal-overlay" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(15, 23, 42, 0.6); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); z-index: 1000; align-items: center; justify-content: center; padding: 1.5rem; transition: var(--transition-smooth);">
    <div class="monthly-breakdown-card" style="width: 100%; max-width: 480px; margin-bottom: 0; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: var(--radius-lg); box-shadow: var(--shadow-lg); animation: modalSlideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;">
        
        <!-- Modal Header -->
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--color-border); padding-bottom: 1rem; margin-bottom: 1.5rem;">
            <h3 style="font-size: 1.15rem; font-weight: 700; color: var(--color-dark);">Ubah Catatan Transaksi</h3>
            <button onclick="closeEditTransactionModal()" style="background: none; border: none; font-size: 1.5rem; color: var(--text-muted); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: var(--transition-smooth);">
                <ion-icon name="close-outline"></ion-icon>
            </button>
        </div>

        <!-- Modal Form -->
        <form method="POST" action="<?= baseUrl('transactions/edit') ?>">
            <input type="hidden" name="id" id="editTxId" value="">
            
            <!-- Amount Field -->
            <div class="form-group mb-3">
                <label for="editTxAmount">Jumlah Uang (Rupiah) <span class="text-danger">*</span></label>
                <div class="input-currency-wrapper">
                    <span class="currency-prefix">Rp</span>
                    <input type="number" name="amount" id="editTxAmount" class="form-control" placeholder="0" min="1" step="any" required>
                </div>
            </div>

            <!-- Transaction Type Toggle -->
            <div class="form-group mb-3">
                <label>Jenis Transaksi <span class="text-danger">*</span></label>
                <div class="type-selector-group">
                    <label class="type-selector-label type-expense" id="edit-type-label-expense">
                        <input type="radio" name="type" id="editTxTypeExpense" value="expense" required>
                        <ion-icon name="arrow-up-circle-outline"></ion-icon>
                        <span>Pengeluaran</span>
                    </label>
                    <label class="type-selector-label type-income" id="edit-type-label-income">
                        <input type="radio" name="type" id="editTxTypeIncome" value="income" required>
                        <ion-icon name="arrow-down-circle-outline"></ion-icon>
                        <span>Pemasukan</span>
                    </label>
                </div>
            </div>

            <!-- Category Field -->
            <div class="form-group mb-3">
                <label for="editTxCategoryId">Kategori Transaksi</label>
                <select name="category_id" id="editTxCategoryId" class="form-control">
                    <option value="">-- Pilih Kategori --</option>
                    <!-- Expense categories -->
                    <?php foreach ($expenseCategories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" data-type="expense" class="edit-cat-option">
                            <?= htmlspecialchars($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                    <!-- Income categories -->
                    <?php foreach ($incomeCategories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" data-type="income" class="edit-cat-option">
                            <?= htmlspecialchars($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Date Field -->
            <div class="form-group mb-3">
                <label for="editTxDate">Tanggal Transaksi <span class="text-danger">*</span></label>
                <input type="date" name="date" id="editTxDate" class="form-control" required>
            </div>

            <!-- Description Field -->
            <div class="form-group mb-4">
                <label for="editTxDescription">Keterangan / Deskripsi</label>
                <textarea name="description" id="editTxDescription" class="form-control" rows="3" placeholder="Contoh: Belanja beras, bayar wifi, dll."></textarea>
            </div>

            <!-- Modal Actions Footer -->
            <div style="display: flex; gap: 0.75rem; justify-content: flex-end; border-top: 1px solid var(--color-border); padding-top: 1.25rem; margin-top: 1.5rem;">
                <button type="button" class="btn btn-secondary" onclick="closeEditTransactionModal()">Batal</button>
                <button type="submit" class="btn btn-primary">
                    <ion-icon name="save-outline" class="mr-2"></ion-icon>
                    <span>Simpan Perubahan</span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal CSS Animations -->
<style>
    .modal-overlay {
        animation: fadeInBg 0.25s ease forwards;
    }

    @keyframes fadeInBg {
        from { background-color: rgba(15, 23, 42, 0); }
        to { background-color: rgba(15, 23, 42, 0.6); }
    }

    @keyframes modalSlideUp {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<!-- Interactive Client-side Script for Category Toggling -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Quick Add Form Handlers
    const radioExpense = document.querySelector('input[value="expense"]');
    const radioIncome = document.querySelector('input[value="income"]');
    const labelExpense = document.getElementById('type-label-expense');
    const labelIncome = document.getElementById('type-label-income');
    const categorySelect = document.getElementById('category_id');
    const catOptions = document.querySelectorAll('.cat-option');

    function updateCategoryDropdown(selectedType) {
        categorySelect.value = '';
        catOptions.forEach(opt => {
            if (opt.getAttribute('data-type') === selectedType) {
                opt.style.display = 'block';
            } else {
                opt.style.display = 'none';
            }
        });
    }

    radioExpense.addEventListener('change', function() {
        if (this.checked) {
            labelExpense.classList.add('active');
            labelIncome.classList.remove('active');
            updateCategoryDropdown('expense');
        }
    });

    radioIncome.addEventListener('change', function() {
        if (this.checked) {
            labelIncome.classList.add('active');
            labelExpense.classList.remove('active');
            updateCategoryDropdown('income');
        }
    });

    updateCategoryDropdown('expense');

    // ==========================================================================
    // TRANSACTION EDIT MODAL HANDLING
    // ==========================================================================
    const editModal = document.getElementById('editTransactionModal');
    const editTxId = document.getElementById('editTxId');
    const editTxAmount = document.getElementById('editTxAmount');
    const editTxDate = document.getElementById('editTxDate');
    const editTxDescription = document.getElementById('editTxDescription');
    const editTxCategoryId = document.getElementById('editTxCategoryId');
    const editCatOptions = document.querySelectorAll('.edit-cat-option');

    const editRadioExpense = document.getElementById('editTxTypeExpense');
    const editRadioIncome = document.getElementById('editTxTypeIncome');
    const editLabelExpense = document.getElementById('edit-type-label-expense');
    const editLabelIncome = document.getElementById('edit-type-label-income');

    function updateEditCategoryDropdown(selectedType, preselectedValue = '') {
        editCatOptions.forEach(opt => {
            if (opt.getAttribute('data-type') === selectedType) {
                opt.style.display = 'block';
            } else {
                opt.style.display = 'none';
            }
        });
        editTxCategoryId.value = preselectedValue;
    }

    window.openEditTransactionModal = function(tx) {
        editTxId.value = tx.id;
        editTxAmount.value = Math.round(tx.amount); // Make sure float is rounded to clean integer in rupiah
        editTxDate.value = tx.date;
        editTxDescription.value = tx.description;

        if (tx.type === 'expense') {
            editRadioExpense.checked = true;
            editRadioIncome.checked = false;
            editLabelExpense.classList.add('active');
            editLabelIncome.classList.remove('active');
            updateEditCategoryDropdown('expense', tx.category_id || '');
        } else {
            editRadioIncome.checked = true;
            editRadioExpense.checked = false;
            editLabelIncome.classList.add('active');
            editLabelExpense.classList.remove('active');
            updateEditCategoryDropdown('income', tx.category_id || '');
        }

        editModal.style.display = 'flex';
    };

    window.closeEditTransactionModal = function() {
        editModal.style.display = 'none';
    };

    editModal.addEventListener('click', function(e) {
        if (e.target === editModal) {
            closeEditTransactionModal();
        }
    });

    editRadioExpense.addEventListener('change', function() {
        if (this.checked) {
            editLabelExpense.classList.add('active');
            editLabelIncome.classList.remove('active');
            updateEditCategoryDropdown('expense');
        }
    });

    editRadioIncome.addEventListener('change', function() {
        if (this.checked) {
            editLabelIncome.classList.add('active');
            editLabelExpense.classList.remove('active');
            updateEditCategoryDropdown('income');
        }
    });
});
</script>
