<?php
/**
 * Dashboard View
 * Displays overall stats, recent transactions, and category analysis
 */

// Helper to format Rupiah currency
if (!function_exists('formatRupiah')) {
    function formatRupiah(float $amount): string {
        return 'Rp ' . number_format($amount, 0, ',', '.');
    }
}
?>

<div class="dashboard-grid">
    <!-- Stat Card 1: Balance -->
    <div class="stat-card balance-card">
        <div class="stat-icon-wrapper">
            <ion-icon name="wallet-outline"></ion-icon>
        </div>
        <div class="stat-details">
            <span class="stat-label">Saldo Aktif Rumah Tangga</span>
            <h2 class="stat-value"><?= formatRupiah($summary['balance']) ?></h2>
            <div class="stat-badge <?= $summary['balance'] >= 0 ? 'badge-success' : 'badge-danger' ?>">
                <ion-icon name="<?= $summary['balance'] >= 0 ? 'trending-up-outline' : 'trending-down-outline' ?>"></ion-icon>
                <span>Status Stabil</span>
            </div>
        </div>
        <div class="card-glow" style="background: radial-gradient(circle at right, rgba(99, 102, 241, 0.15), transparent 60%);"></div>
    </div>

    <!-- Stat Card 2: Income -->
    <div class="stat-card income-card">
        <div class="stat-icon-wrapper">
            <ion-icon name="arrow-down-circle-outline"></ion-icon>
        </div>
        <div class="stat-details">
            <span class="stat-label">Total Pemasukan</span>
            <h2 class="stat-value"><?= formatRupiah($summary['total_income']) ?></h2>
            <span class="stat-subtext">Kumulatif seluruh catatan</span>
        </div>
        <div class="card-glow" style="background: radial-gradient(circle at right, rgba(16, 185, 129, 0.15), transparent 60%);"></div>
    </div>

    <!-- Stat Card 3: Expense -->
    <div class="stat-card expense-card">
        <div class="stat-icon-wrapper">
            <ion-icon name="arrow-up-circle-outline"></ion-icon>
        </div>
        <div class="stat-details">
            <span class="stat-label">Total Pengeluaran</span>
            <h2 class="stat-value"><?= formatRupiah($summary['total_expense']) ?></h2>
            <span class="stat-subtext">Kumulatif seluruh catatan</span>
        </div>
        <div class="card-glow" style="background: radial-gradient(circle at right, rgba(239, 68, 68, 0.15), transparent 60%);"></div>
    </div>
</div>

<!-- Secondary Stats: Current Month Details -->
<div class="monthly-breakdown-card">
    <div class="card-header-clean">
        <div class="header-icon-title">
            <ion-icon name="calendar-number-outline" class="text-primary"></ion-icon>
            <div>
                <h3>Ringkasan Periode Ini (<?= $periodLabel ?>)</h3>
                <p class="text-muted text-xs">Perkembangan pemasukan & pengeluaran dari tanggal <?= $periodStartFormatted ?> s/d <?= $periodEndFormatted ?>.</p>
            </div>
        </div>
    </div>
    <div class="monthly-grid">
        <div class="monthly-stat-item">
            <span class="monthly-label">Pemasukan Periode Ini</span>
            <h4 class="text-emerald font-weight-bold"><?= formatRupiah($monthlySummary['total_income']) ?></h4>
        </div>
        <div class="monthly-separator"></div>
        <div class="monthly-stat-item">
            <span class="monthly-label">Pengeluaran Periode Ini</span>
            <h4 class="text-danger font-weight-bold"><?= formatRupiah($monthlySummary['total_expense']) ?></h4>
        </div>
        <div class="monthly-separator"></div>
        <div class="monthly-stat-item">
            <span class="monthly-label">Sisa Selisih Periode Ini</span>
            <h4 class="<?= $monthlySummary['balance'] >= 0 ? 'text-emerald' : 'text-danger' ?> font-weight-bold">
                <?= formatRupiah($monthlySummary['balance']) ?>
            </h4>
        </div>
    </div>
</div>

<div class="row-layout">
    <!-- Recent Transactions Cards (Modern Card List) -->
    <div class="col-8 card-widget">
        <div class="card-widget-header">
            <h3>5 Transaksi Terkini</h3>
            <a href="<?= baseUrl('transactions') ?>" class="btn-link">
                <span>Lihat Semua</span>
                <ion-icon name="arrow-forward-outline"></ion-icon>
            </a>
        </div>
        
        <div class="tx-cards-container">
            <?php if (empty($recentTransactions)): ?>
                <div class="text-center py-4 text-muted">
                    <ion-icon name="receipt-outline" style="font-size: 2rem;"></ion-icon>
                    <p class="mt-2">Belum ada transaksi tercatat.</p>
                </div>
            <?php else: ?>
                <div class="tx-cards-list">
                    <?php foreach ($recentTransactions as $tx): ?>
                        <div class="tx-card-item">
                            <!-- Top Row: Icon + Description Title and Amount -->
                            <div class="tx-card-header-row">
                                <div class="tx-card-title-group">
                                    <div class="tx-icon-avatar" style="background-color: <?= $tx['category_color'] ?? ($tx['type'] === 'income' ? '#10b981' : '#ef4444') ?>18; color: <?= $tx['category_color'] ?? ($tx['type'] === 'income' ? '#10b981' : '#ef4444') ?>;">
                                        <ion-icon name="<?= $tx['category_icon'] ?? ($tx['type'] === 'income' ? 'arrow-down-circle-outline' : 'arrow-up-circle-outline') ?>"></ion-icon>
                                    </div>
                                    <strong class="tx-description-text"><?= htmlspecialchars($tx['description'] ?: 'Transaksi Tanpa Keterangan') ?></strong>
                                </div>

                                <span class="tx-amount-value <?= $tx['type'] === 'income' ? 'text-emerald' : 'text-danger' ?>">
                                    <?= $tx['type'] === 'income' ? '+' : '-' ?> <?= formatRupiah($tx['amount']) ?>
                                </span>
                            </div>

                            <!-- Bottom Row: Date & Category Pill -->
                            <div class="tx-card-footer-row">
                                <div class="tx-sub-meta">
                                    <span class="tx-date-badge">
                                        <ion-icon name="calendar-outline"></ion-icon>
                                        <?= date('d M Y', strtotime($tx['date'])) ?>
                                    </span>
                                    <span class="badge-category-pill" style="background-color: <?= $tx['category_color'] ?? '#6366f1' ?>15; color: <?= $tx['category_color'] ?? '#6366f1' ?>;">
                                        <ion-icon name="<?= $tx['category_icon'] ?? 'bookmark-outline' ?>"></ion-icon>
                                        <span><?= htmlspecialchars($tx['category_name'] ?? 'Lainnya') ?></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Category Spending Chart/Bars -->
    <div class="col-4 card-widget">
        <div class="card-widget-header">
            <h3>Alokasi Pengeluaran</h3>
        </div>
        
        <div class="category-bars-list">
            <?php 
            $totalExpenses = array_sum(array_column($categoryExpenses, 'total_amount'));
            if (empty($categoryExpenses)): 
            ?>
                <p class="text-center py-4 text-muted">Belum ada data pengeluaran.</p>
            <?php else: ?>
                <?php foreach ($categoryExpenses as $cat): 
                    $percent = $totalExpenses > 0 ? round(($cat['total_amount'] / $totalExpenses) * 100) : 0;
                ?>
                    <div class="category-bar-item animate-fade-in">
                        <div class="bar-details">
                            <span class="bar-name">
                                <span class="bar-dot" style="background-color: <?= $cat['category_color'] ?>;"></span>
                                <?= htmlspecialchars($cat['category_name']) ?>
                            </span>
                            <span class="bar-value"><?= formatRupiah($cat['total_amount']) ?> <small class="text-muted">(<?= $percent ?>%)</small></span>
                        </div>
                        <div class="progress-track">
                            <div class="progress-fill" style="background-color: <?= $cat['category_color'] ?>; width: <?= $percent ?>%;"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
