<?php
/**
 * Expense Allocation Report View (Rekap Alokasi Pengeluaran Semua Kategori)
 * Cycle: Starts on the 28th payday of the previous month and ends on the 27th.
 *
 * @var string $prevMonthValue
 * @var string $nextMonthValue
 * @var string $selectedMonthValue
 * @var array $availableMonths
 * @var string $periodLabel
 * @var string $periodStartFormatted
 * @var string $periodEndFormatted
 * @var int $activeCategoriesCount
 * @var int $totalCategoriesCount
 * @var float $totalExpense
 * @var float $totalIncome
 * @var float $periodBalance
 * @var array $categoryAllocations
 * @var array $periodExpenses
 */

// Safe fallback initializations for static PHP analysis
$prevMonthValue = $prevMonthValue ?? '';
$nextMonthValue = $nextMonthValue ?? '';
$selectedMonthValue = $selectedMonthValue ?? date('Y-m');
$availableMonths = $availableMonths ?? [];
$periodLabel = $periodLabel ?? '';
$periodStartFormatted = $periodStartFormatted ?? '';
$periodEndFormatted = $periodEndFormatted ?? '';
$activeCategoriesCount = $activeCategoriesCount ?? 0;
$totalCategoriesCount = $totalCategoriesCount ?? 0;
$totalExpense = $totalExpense ?? 0.0;
$totalIncome = $totalIncome ?? 0.0;
$periodBalance = $periodBalance ?? 0.0;
$categoryAllocations = $categoryAllocations ?? [];
$periodExpenses = $periodExpenses ?? [];

if (!function_exists('formatRupiah')) {
    function formatRupiah(float $amount): string {
        return 'Rp ' . number_format($amount, 0, ',', '.');
    }
}
?>

<div class="report-wrapper animate-fade-in">
    <!-- Top Filter Bar & Toolbar -->
    <div class="card-widget report-filter-card mb-4">
        <div class="report-filter-header">
            <div class="report-title-section">
                <div class="report-icon-badge">
                    <ion-icon name="pie-chart-outline"></ion-icon>
                </div>
                <div>
                    <h2 class="report-title">Rekap Alokasi Pengeluaran</h2>
                    <p class="text-muted text-sm">
                        Siklus Keuangan Bulanan: <strong>Tanggal 28 s/d Tanggal 27</strong> (Awal Tanggal Gajian)
                    </p>
                </div>
            </div>

            <!-- Action controls & Month selection -->
            <div class="report-controls">
                <form action="<?= baseUrl('reports') ?>" method="GET" class="month-picker-form" id="monthForm">
                    <div class="month-selector-group">
                        <a href="<?= baseUrl('reports?month=' . $prevMonthValue) ?>" class="btn-nav-month" title="Bulan Sebelumnya">
                            <ion-icon name="chevron-back-outline"></ion-icon>
                        </a>
                        
                        <div class="select-wrapper">
                            <ion-icon name="calendar-outline" class="select-icon"></ion-icon>
                            <select name="month" class="form-control select-month-input" onchange="document.getElementById('monthForm').submit();">
                                <?php foreach ($availableMonths as $val => $m): ?>
                                    <option value="<?= $val ?>" <?= $val === $selectedMonthValue ? 'selected' : '' ?>>
                                        <?= $m['label'] ?> (<?= $m['range'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <a href="<?= baseUrl('reports?month=' . $nextMonthValue) ?>" class="btn-nav-month" title="Bulan Berikutnya">
                            <ion-icon name="chevron-forward-outline"></ion-icon>
                        </a>
                    </div>
                </form>

                <button onclick="window.print()" class="btn btn-secondary btn-print no-print">
                    <ion-icon name="print-outline"></ion-icon>
                    <span>Cetak Laporan</span>
                </button>
            </div>
        </div>

        <!-- Budget Period Info Banner -->
        <div class="period-info-banner mt-3">
            <div class="period-badge-item">
                <ion-icon name="time-outline" class="text-primary"></ion-icon>
                <span>Periode Terpilih: <strong><?= htmlspecialchars($periodLabel) ?></strong></span>
            </div>
            <div class="period-badge-divider"></div>
            <div class="period-badge-item">
                <ion-icon name="calendar-clear-outline" class="text-emerald"></ion-icon>
                <span>Rentang Tanggal Gajian: <strong><?= $periodStartFormatted ?></strong> s/d <strong><?= $periodEndFormatted ?></strong></span>
            </div>
            <div class="period-badge-divider"></div>
            <div class="period-badge-item">
                <ion-icon name="layers-outline" class="text-primary"></ion-icon>
                <span>Kategori Aktif: <strong><?= $activeCategoriesCount ?> dari <?= $totalCategoriesCount ?> Kategori</strong></span>
            </div>
        </div>
    </div>

    <!-- Summary Statistics Grid -->
    <div class="dashboard-grid mb-4">
        <!-- Card 1: Total Expense -->
        <div class="stat-card expense-card">
            <div class="stat-icon-wrapper">
                <ion-icon name="arrow-up-circle-outline"></ion-icon>
            </div>
            <div class="stat-details">
                <span class="stat-label">Total Pengeluaran Periode Ini</span>
                <h2 class="stat-value text-danger"><?= formatRupiah($totalExpense) ?></h2>
                <span class="stat-subtext">Dari total <?= count($periodExpenses) ?> transaksi pengeluaran</span>
            </div>
            <div class="card-glow" style="background: radial-gradient(circle at right, rgba(239, 68, 68, 0.15), transparent 60%);"></div>
        </div>

        <!-- Card 2: Total Income -->
        <div class="stat-card income-card">
            <div class="stat-icon-wrapper">
                <ion-icon name="arrow-down-circle-outline"></ion-icon>
            </div>
            <div class="stat-details">
                <span class="stat-label">Total Pemasukan Periode Ini</span>
                <h2 class="stat-value text-emerald"><?= formatRupiah($totalIncome) ?></h2>
                <span class="stat-subtext">Pemasukan tercatat siklus ini</span>
            </div>
            <div class="card-glow" style="background: radial-gradient(circle at right, rgba(16, 185, 129, 0.15), transparent 60%);"></div>
        </div>

        <!-- Card 3: Period Balance / Surplus -->
        <div class="stat-card balance-card">
            <div class="stat-icon-wrapper">
                <ion-icon name="wallet-outline"></ion-icon>
            </div>
            <div class="stat-details">
                <span class="stat-label">Sisa Selisih Periode</span>
                <h2 class="stat-value <?= $periodBalance >= 0 ? 'text-emerald' : 'text-danger' ?>">
                    <?= formatRupiah($periodBalance) ?>
                </h2>
                <div class="stat-badge <?= $periodBalance >= 0 ? 'badge-success' : 'badge-danger' ?>">
                    <ion-icon name="<?= $periodBalance >= 0 ? 'checkmark-circle-outline' : 'warning-outline' ?>"></ion-icon>
                    <span><?= $periodBalance >= 0 ? 'Surplus Alokasi' : 'Defisit Anggaran' ?></span>
                </div>
            </div>
            <div class="card-glow" style="background: radial-gradient(circle at right, rgba(99, 102, 241, 0.15), transparent 60%);"></div>
        </div>
    </div>

    <!-- Visual Stacked Proportional Bar Chart -->
    <div class="card-widget mb-4">
        <div class="card-widget-header">
            <h3>Visualisasi Proposional Alokasi Belanja</h3>
            <span class="text-muted text-xs">Persentase kontribusi tiap kategori terhadap total pengeluaran</span>
        </div>

        <?php if ($totalExpense > 0): ?>
            <!-- Multi-color Segmented Stacked Bar -->
            <div class="stacked-bar-container">
                <div class="stacked-bar-track">
                    <?php foreach ($categoryAllocations as $cat): 
                        if ($cat['total_amount'] <= 0) continue;
                        $percent = round(($cat['total_amount'] / $totalExpense) * 100, 1);
                    ?>
                        <div class="stacked-bar-segment" 
                             style="width: <?= $percent ?>%; background-color: <?= $cat['category_color'] ?>;"
                             title="<?= htmlspecialchars($cat['category_name']) ?>: <?= formatRupiah($cat['total_amount']) ?> (<?= $percent ?>%)">
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Legend Grid -->
            <div class="report-legend-grid mt-3">
                <?php foreach ($categoryAllocations as $cat): 
                    if ($cat['total_amount'] <= 0) continue;
                    $percent = round(($cat['total_amount'] / $totalExpense) * 100, 1);
                ?>
                    <div class="legend-item">
                        <span class="legend-dot" style="background-color: <?= $cat['category_color'] ?>;"></span>
                        <span class="legend-name"><?= htmlspecialchars($cat['category_name']) ?></span>
                        <span class="legend-percent font-weight-bold"><?= $percent ?>%</span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-4 text-muted">
                <ion-icon name="information-circle-outline" style="font-size: 2rem;"></ion-icon>
                <p>Belum ada catatan pengeluaran pada periode <strong><?= htmlspecialchars($periodLabel) ?></strong> (28 - 27).</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Category Expense Allocation Cards (Rekap Alokasi Pengeluaran Semua Kategori - Modern Card List) -->
    <div class="card-widget mb-4">
        <div class="card-widget-header">
            <div>
                <h3>Rekapitulasi Alokasi Pengeluaran Kategori</h3>
                <p class="text-muted text-xs">Rincian alokasi pengeluaran per kategori disajikan secara visual & transparan.</p>
            </div>
            <span class="badge-category" style="background-color: #e0e7ff; color: #4f46e5;">
                <ion-icon name="apps-outline"></ion-icon>
                <span><?= count($categoryAllocations) ?> Kategori</span>
            </span>
        </div>

        <div class="allocation-cards-container">
            <?php if (empty($categoryAllocations)): ?>
                <div class="text-center py-4 text-muted">Tidak ada data kategori pengeluaran ditemukan.</div>
            <?php else: ?>
                <div class="allocation-cards-list">
                    <?php 
                    $no = 1;
                    foreach ($categoryAllocations as $cat): 
                        $amt = (float)$cat['total_amount'];
                        $percent = $totalExpense > 0 ? round(($amt / $totalExpense) * 100, 1) : 0;
                        $hasExpense = $amt > 0;
                    ?>
                        <div class="allocation-card-item <?= $hasExpense ? '' : 'zero-expense-card' ?>" 
                             style="cursor: pointer;" 
                             onclick="filterReportTransactions(<?= $cat['category_id'] ?? $cat['id'] ?? 0 ?>); document.getElementById('reportTxWidget').scrollIntoView({behavior: 'smooth'});"
                             title="Klik untuk melihat rincian transaksi <?= htmlspecialchars($cat['category_name']) ?>">
                            <!-- Top row: Index number, Category icon, Category title, Transaction badge, and Amount -->
                            <div class="allocation-card-top">
                                <div class="allocation-card-left">
                                    <span class="allocation-index-number"><?= $no++ ?></span>
                                    <div class="allocation-icon-avatar" style="background-color: <?= $cat['category_color'] ?>18; color: <?= $cat['category_color'] ?>;">
                                        <ion-icon name="<?= $cat['category_icon'] ?? 'bookmark-outline' ?>"></ion-icon>
                                    </div>
                                    <div class="allocation-title-info">
                                        <strong class="allocation-cat-name"><?= htmlspecialchars($cat['category_name']) ?></strong>
                                        <div class="allocation-sub-info">
                                            <?php if ($cat['transaction_count'] > 0): ?>
                                                <span class="allocation-tx-tag">
                                                    <ion-icon name="receipt-outline"></ion-icon>
                                                    <?= $cat['transaction_count'] ?> Transaksi
                                                </span>
                                            <?php else: ?>
                                                <span class="text-muted text-xs">Belum ada transaksi</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="allocation-card-right">
                                    <span class="allocation-amount-value <?= $hasExpense ? 'text-danger' : 'text-muted' ?>">
                                        <?= formatRupiah($amt) ?>
                                    </span>
                                </div>
                            </div>

                            <!-- Bottom row: Proportional Progress Bar and Percent Label -->
                            <div class="allocation-card-bottom mt-2">
                                <div class="allocation-progress-wrapper">
                                    <div class="progress-track allocation-track">
                                        <div class="progress-fill" style="background-color: <?= $cat['category_color'] ?>; width: <?= $percent ?>%;"></div>
                                    </div>
                                </div>
                                <span class="allocation-percent-badge" style="background-color: <?= $cat['category_color'] ?>15; color: <?= $cat['category_color'] ?>;">
                                    <?= $percent ?>%
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Modern Total Summary Banner Card -->
                <div class="allocation-summary-card mt-3">
                    <div class="summary-card-left">
                        <div class="summary-icon-circle">
                            <ion-icon name="calculator-outline"></ion-icon>
                        </div>
                        <div>
                            <span class="summary-card-label">TOTAL PENGELUARAN SIKLUS INI</span>
                            <span class="summary-card-subtext">Dari total <?= array_sum(array_column($categoryAllocations, 'transaction_count')) ?> transaksi di seluruh kategori</span>
                        </div>
                    </div>
                    <div class="summary-card-right">
                        <h3 class="summary-total-amount text-danger"><?= formatRupiah($totalExpense) ?></h3>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Detailed Expense Transactions Breakdown (Modern Transaction Card List) -->
    <div class="card-widget mb-4" id="reportTxWidget">
        <div class="card-widget-header" style="flex-wrap: wrap; gap: 1rem;">
            <div>
                <h3>Rincian Transaksi Pengeluaran Periode <?= htmlspecialchars($periodLabel) ?></h3>
                <p class="text-muted text-xs">Catatan detail setiap pengeluaran yang terjadi antara <?= $periodStartFormatted ?> s/d <?= $periodEndFormatted ?>.</p>
            </div>
            <a href="<?= baseUrl('transactions') ?>" class="btn-link no-print">
                <span>Kelola Transaksi</span>
                <ion-icon name="arrow-forward-outline"></ion-icon>
            </a>
        </div>

        <!-- Category Filter Chips Bar -->
        <?php if (!empty($periodExpenses)): ?>
            <div class="category-filter-bar no-print">
                <span class="filter-label">Filter Kategori:</span>
                <div class="filter-chips-wrapper">
                    <button type="button" class="category-chip-btn active" data-category-id="all" onclick="filterReportTransactions('all', this)">
                        <ion-icon name="grid-outline"></ion-icon>
                        <span>Semua Kategori</span>
                        <span class="chip-count"><?= count($periodExpenses) ?></span>
                    </button>

                    <?php 
                    // Group category counts from periodExpenses
                    $catCounts = [];
                    foreach ($periodExpenses as $tx) {
                        $cId = $tx['category_id'] ?? 0;
                        if (!isset($catCounts[$cId])) {
                            $catCounts[$cId] = [
                                'id' => $cId,
                                'name' => $tx['category_name'] ?? 'Lainnya',
                                'color' => $tx['category_color'] ?? '#6366f1',
                                'icon' => $tx['category_icon'] ?? 'bookmark-outline',
                                'count' => 0
                            ];
                        }
                        $catCounts[$cId]['count']++;
                    }

                    foreach ($catCounts as $cId => $cat): 
                    ?>
                        <button type="button" class="category-chip-btn" data-category-id="<?= $cId ?>" onclick="filterReportTransactions(<?= $cId ?>, this)">
                            <ion-icon name="<?= $cat['icon'] ?>"></ion-icon>
                            <span><?= htmlspecialchars($cat['name']) ?></span>
                            <span class="chip-count" style="background-color: <?= $cat['color'] ?>20; color: <?= $cat['color'] ?>;"><?= $cat['count'] ?></span>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="tx-cards-container">
            <?php if (empty($periodExpenses)): ?>
                <div class="text-center py-4 text-muted">
                    <ion-icon name="receipt-outline" style="font-size: 2rem;"></ion-icon>
                    <p class="mt-2">Belum ada rincian pengeluaran tercatat pada periode ini.</p>
                </div>
            <?php else: ?>
                <div class="tx-cards-list" id="reportTxCardsList">
                    <?php foreach ($periodExpenses as $tx): ?>
                        <div class="tx-card-item report-tx-item" data-category-id="<?= $tx['category_id'] ?? 0 ?>">
                            <!-- Top Row: Icon + Description Title and Amount -->
                            <div class="tx-card-header-row">
                                <div class="tx-card-title-group">
                                    <div class="tx-icon-avatar" style="background-color: <?= $tx['category_color'] ?? '#ef4444' ?>18; color: <?= $tx['category_color'] ?? '#ef4444' ?>;">
                                        <ion-icon name="<?= $tx['category_icon'] ?? 'bag-handle-outline' ?>"></ion-icon>
                                    </div>
                                    <strong class="tx-description-text"><?= htmlspecialchars($tx['description'] ?: 'Pengeluaran tanpa keterangan') ?></strong>
                                </div>

                                <span class="tx-amount-value text-danger">
                                    - <?= formatRupiah($tx['amount']) ?>
                                </span>
                            </div>

                            <!-- Bottom Row: Date & Category Pill -->
                            <div class="tx-card-footer-row">
                                <div class="tx-sub-meta">
                                    <span class="tx-date-badge">
                                        <ion-icon name="calendar-outline"></ion-icon>
                                        <?= date('d M Y', strtotime($tx['date'])) ?>
                                    </span>
                                    <span class="badge-category-pill" style="background-color: <?= $tx['category_color'] ?? '#6366f1' ?>15; color: <?= $tx['category_color'] ?? '#6366f1' ?>;">
                                        <ion-icon name="<?= $tx['category_icon'] ?? 'bookmark-outline' ?>"></ion-icon>
                                        <span><?= htmlspecialchars($tx['category_name'] ?? 'Lainnya') ?></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div id="noFilterResult" class="text-center py-5 text-muted" style="display: none;">
                    <ion-icon name="funnel-outline" style="font-size: 2.5rem; color: var(--text-muted); opacity: 0.6;"></ion-icon>
                    <p class="mt-2">Tidak ditemukan rincian pengeluaran untuk filter kategori ini.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function filterReportTransactions(catId, btnElement) {
    // 1. Update active chip styling
    const chips = document.querySelectorAll('.category-chip-btn');
    chips.forEach(chip => chip.classList.remove('active'));
    
    if (btnElement) {
        btnElement.classList.add('active');
    } else {
        const targetChip = document.querySelector(`.category-chip-btn[data-category-id="${catId}"]`);
        if (targetChip) targetChip.classList.add('active');
    }

    // 2. Filter transaction cards
    const items = document.querySelectorAll('.report-tx-item');
    let visibleCount = 0;

    items.forEach(item => {
        const itemCatId = item.getAttribute('data-category-id');
        if (catId === 'all' || itemCatId == catId) {
            item.style.display = 'flex';
            visibleCount++;
        } else {
            item.style.display = 'none';
        }
    });

    // 3. Toggle empty state if no matching items
    const noResult = document.getElementById('noFilterResult');
    if (noResult) {
        noResult.style.display = visibleCount === 0 ? 'block' : 'none';
    }
}
</script>
