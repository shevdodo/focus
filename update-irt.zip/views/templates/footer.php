            </div> <!-- End of content-body -->
            
            <!-- Global Footer -->
            <footer class="main-footer">
                <div class="footer-content">
                    <p>&copy; <?= date('Y') ?> <strong>IRT Finansial</strong>. Pencatatan Keuangan Rumah Tangga Native.</p>
                    <div class="footer-links">
                        <span>Antigravity Architecture</span>
                    </div>
                </div>
            </footer>
        </main>
    </div> <!-- End of app-container -->
</body>
</html>
